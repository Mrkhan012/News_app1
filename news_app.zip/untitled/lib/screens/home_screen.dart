import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:intl/intl.dart';

import '../model/categories_news_model.dart';
import '../model/news_headlines_model.dart';
import '../utils/colors.dart';
import '../view/news_view_model.dart';
import 'bottom_news_screen.dart';
import 'category_screen.dart';
import 'news_detail_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

enum NewsFilterList { bbcNews, bbcSport, espn, foxSports, theverge }

class _HomeScreenState extends State<HomeScreen> {
  NewsFilterList? selectedMenu;
  String name = "bbc-news";
  final format = DateFormat('MMMM dd, yyyy');

  NewsViewModel newsViewModel = NewsViewModel();

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final height = MediaQuery.of(context).size.height;

    return Scaffold(
      backgroundColor: beige,
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => const CategoryScreen(),
              ),
            );
          },
          icon: const Icon(
            Icons.menu_book_rounded,
            color: Colors.black,
          ),
        ),
        backgroundColor: beige,
        elevation: 0,
        title: const Center(
          child: Text(
            "News",
            style: TextStyle(
              color: charcoal,
              fontWeight: FontWeight.bold,
              fontSize: 24,
            ),
          ),
        ),
        actions: [
          PopupMenuButton<NewsFilterList>(
            initialValue: selectedMenu,
            icon: const Icon(
              Icons.more_vert,
              color: Colors.black,
            ),
            color: beige,
            onSelected: (NewsFilterList item) {
              setState(() {
                selectedMenu = item;
                switch (item) {
                  case NewsFilterList.bbcNews:
                    name = "bbc-news";
                    break;
                  case NewsFilterList.bbcSport:
                    name = "bbc-sport";
                    break;
                  case NewsFilterList.espn:
                    name = "espn";
                    break;
                  case NewsFilterList.foxSports:
                    name = "fox-sports";
                    break;
                  case NewsFilterList.theverge:
                    name = "the-verge";
                    break;
                }
              });
            },
            itemBuilder: (BuildContext context) =>
            <PopupMenuEntry<NewsFilterList>>[
              const PopupMenuItem<NewsFilterList>(
                value: NewsFilterList.bbcNews,
                child: Text("BBC News"),
              ),
              const PopupMenuItem<NewsFilterList>(
                value: NewsFilterList.bbcSport,
                child: Text("BBC Sports"),
              ),
              const PopupMenuItem<NewsFilterList>(
                value: NewsFilterList.espn,
                child: Text("ESPN"),
              ),
              const PopupMenuItem<NewsFilterList>(
                value: NewsFilterList.theverge,
                child: Text("The verge"),
              ),
              const PopupMenuItem<NewsFilterList>(
                value: NewsFilterList.foxSports,
                child: Text("Fox Sports"),
              ),
            ],
          )
        ],
      ),
      body: FutureBuilder<NewsHeadlineModel>(
        future: newsViewModel.getNewsApi(name),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(
                color: roseWood,
              ),
            );
          } else if (snapshot.hasError) {
            return Center(child: Text("Error: ${snapshot.error}"));
          } else {
            return SingleChildScrollView(
              child: Column(
                children: [
                  SizedBox(
                    height: height * 0.6,
                    child: ListView.builder(
                      shrinkWrap: true,
                      itemCount: snapshot.data?.articles?.length ?? 0,
                      scrollDirection: Axis.horizontal,
                      itemBuilder: (context, index) {
                        DateTime dateTime = DateTime.parse(
                          snapshot.data?.articles?[index].publishedAt.toString() ?? '',
                        );
                        final urlToImage = snapshot.data?.articles?[index].urlToImage;
                        if (urlToImage != null && urlToImage.isNotEmpty) {
                          return InkWell(
                            onTap: () {
                              String newsImage =
                                  snapshot.data?.articles?[index].urlToImage ?? '';
                              String newsTitle =
                                  snapshot.data?.articles?[index].title ?? '';
                              String newsDate =
                                  snapshot.data?.articles?[index].publishedAt ?? '';
                              String newsAuthor =
                                  snapshot.data?.articles?[index].author ?? '';
                              String newsDesc =
                                  snapshot.data?.articles?[index].description ?? '';
                              String newsContent =
                                  snapshot.data?.articles?[index].content ?? '';
                              String newsSource =
                                  snapshot.data?.articles?[index].source?.name ?? '';
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => NewsDetailScreen(
                                    newsImage,
                                    newsTitle,
                                    newsDate,
                                    newsAuthor,
                                    newsDesc,
                                    newsContent,
                                    newsSource,
                                  ),
                                ),
                              );
                            },
                            child: SizedBox(
                              width: 315,
                              child: Stack(
                                alignment: Alignment.topCenter,
                                children: [
                                  Container(
                                    height: height * 0.6,
                                    padding: EdgeInsets.symmetric(
                                      horizontal: height * 0.02,
                                    ),
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(20),
                                      child: CachedNetworkImage(
                                        imageUrl: urlToImage,
                                        fit: BoxFit.cover,
                                        placeholder: (context, url) => Container(child: spinkit2),
                                        errorWidget: (context, url, error) => const Icon(
                                          Icons.error_outline_rounded,
                                          color: Colors.red,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    bottom: 20,
                                    child: Card(
                                      elevation: 5,
                                      color: dun,
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(16),
                                      ),
                                      child: Container(
                                        alignment: Alignment.bottomCenter,
                                        padding: const EdgeInsets.all(15),
                                        height: height * 0.18,
                                        child: Column(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            SizedBox(
                                              width: width * 0.7,
                                              child: Text(
                                                snapshot.data?.articles?[index].title.toString() ?? '',
                                                maxLines: 2,
                                                overflow: TextOverflow.ellipsis,
                                                style: GoogleFonts.poppins(
                                                  fontSize: 17,
                                                  fontWeight: FontWeight.w700,
                                                ),
                                              ),
                                            ),
                                            const Spacer(),
                                            SizedBox(
                                              width: width * 0.7,
                                              child: Row(
                                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                children: [
                                                  Flexible(
                                                    fit: FlexFit.loose,
                                                    child: Text(
                                                      snapshot.data?.articles?[index].source?.name.toString() ?? '',
                                                      maxLines: 2,
                                                      overflow: TextOverflow.ellipsis,
                                                      style: GoogleFonts.poppins(
                                                        fontSize: 13,
                                                        fontWeight: FontWeight.w600,
                                                      ),
                                                    ),
                                                  ),
                                                  Text(
                                                    format.format(dateTime),
                                                    maxLines: 2,
                                                    overflow: TextOverflow.ellipsis,
                                                    style: GoogleFonts.poppins(
                                                      fontSize: 12,
                                                      fontWeight: FontWeight.w500,
                                                    ),
                                                  )
                                                ],
                                              ),
                                            )
                                          ],
                                        ),
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                          );
                        } else {
                          return const SizedBox();
                        }
                      },
                    ),
                  ),
                  SingleChildScrollView(
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(6),
                          child: FutureBuilder<CategoriesNewsModel>(
                            future: newsViewModel.getCategoriesApi("General"),
                            builder: (BuildContext context, snapshot) {
                              if (snapshot.connectionState == ConnectionState.waiting) {
                                return const Center(
                                  child: SpinKitCircle(
                                    size: 50,
                                    color: roseWood,
                                  ),
                                );
                              } else if (snapshot.hasData) {
                                return ListView.builder(
                                  shrinkWrap: true,
                                  itemCount: snapshot.data?.articles?.length ?? 0,
                                  itemBuilder: (context, index) {
                                    DateTime dateTime = DateTime.parse(
                                      snapshot.data?.articles?[index].publishedAt.toString() ?? '',
                                    );
                                    return InkWell(
                                      onTap: () {
                                        String newsImage =
                                            snapshot.data?.articles?[index].urlToImage ?? '';
                                        String newsTitle =
                                            snapshot.data?.articles?[index].title ?? '';
                                        String newsDate =
                                            snapshot.data?.articles?[index].publishedAt ?? '';
                                        String newsAuthor =
                                            snapshot.data?.articles?[index].author ?? '';
                                        String newsDesc =
                                            snapshot.data?.articles?[index].description ?? '';
                                        String newsContent =
                                            snapshot.data?.articles?[index].content ?? '';
                                        String newsSource =
                                            snapshot.data?.articles?[index].source?.name ?? '';
                                        Navigator.push(context, MaterialPageRoute(builder: (context) => NewsDetailScreen(
                                          newsImage,
                                          newsTitle,
                                          newsDate,
                                          newsAuthor,
                                          newsDesc,
                                          newsContent,
                                          newsSource,
                                        ))
                                        );
                                      },
                                      child: Padding(
                                        padding: const EdgeInsets.only(bottom: 15),
                                        child: Card(
                                          color: mistryRose,
                                          elevation: 4,
                                          child: Row(
                                            children: [
                                              ClipRRect(
                                                borderRadius: BorderRadius.circular(6),
                                                child: CachedNetworkImage(
                                                  imageUrl: snapshot.data?.articles?[index].urlToImage?.toString() ?? '',
                                                  fit: BoxFit.cover,
                                                  height: height * 0.18,
                                                  width: width * 0.4,
                                                  placeholder: (context, url) => Container(
                                                    child: const Center(
                                                      child: SpinKitCircle(
                                                        size: 50,
                                                        color: roseWood,
                                                      ),
                                                    ),
                                                  ),
                                                  errorWidget: (context, url, error) => const Icon(
                                                    Icons.error_outline,
                                                    color: Colors.red,
                                                  ),
                                                ),
                                              ),
                                              Expanded(
                                                child: Container(
                                                  height: height * 0.18,
                                                  padding: const EdgeInsets.only(left: 15),
                                                  child: Column(
                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                    children: [
                                                      Text(
                                                        snapshot.data?.articles?[index].title.toString() ?? '',
                                                        maxLines: 3,
                                                        style: GoogleFonts.poppins(
                                                          fontSize: 15,
                                                          color: Colors.black54,
                                                          fontWeight: FontWeight.w700,
                                                        ),
                                                      ),
                                                      const Spacer(),
                                                      SizedBox(
                                                        width: width * 0.7,
                                                        child: Row(
                                                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                                                          children: [
                                                            Expanded(
                                                              child: Text(
                                                                snapshot.data?.articles?[index].source?.name.toString() ?? '',
                                                                maxLines: 2,
                                                                style: GoogleFonts.poppins(
                                                                  fontSize: 14,
                                                                  color: Colors.black54,
                                                                  fontWeight: FontWeight.w600,
                                                                ),
                                                              ),
                                                            ),
                                                            Text(
                                                              format.format(dateTime),
                                                              style: GoogleFonts.poppins(
                                                                fontSize: 15,
                                                                fontWeight: FontWeight.w500,
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      )
                                                    ],
                                                  ),
                                                ),
                                              )
                                            ],
                                          ),
                                        ),
                                      ),
                                    );
                                  },
                                );
                              } else if (snapshot.hasError) {
                                return Center(
                                  child: Text("Error: ${snapshot.error}"),
                                );
                              } else {
                                return const Center(
                                  child: Text("No data available."),
                                );
                              }
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          }
        },
      ),
    );
  }
}
