import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';

const primary = Color(0xff4E5283);
const chreey = Color(0xff780000);
const brown = Color(0xff2E0F15);
const skyBlue = Color(0xff95B2B8);
const green = Color(0xff307351);
const black = Color(0xff120309);
const frechGray = Color(0xffD5C5C8);
const mistryRose = Color(0xffFFDBDA);
const charcoal = Color(0xff2A3D45);
const coyote = Color(0xff7A6C5D);
const dun = Color(0xffDDC9B4);
const teaGreen = Color(0xffBDD2A6);
const colunbiaBlue = Color(0xffC9DAEA);
const cyan = Color(0xff03F7EB);
const licorice = Color(0xff191516);
const amaranath = Color(0xffAB2346);
const jungleGreen = Color(0xff00B295);
const yellow = Color(0xffF3B61F);
const oldGold = Color(0xffA29F15);
const roseWood = Color(0xff510D0A);
const ylMnBlue = Color(0xff274C77);
const beige = Color(0xffF2F5DE);
const dodgerBlue = Color(0xff006BA6);
const raspberry = Color(0xffD81159);
const magenta = Color(0xff8F2D56);
const gray = Color(0xff6D6875);


const spinkit2 = SpinKitCircle(
  color: roseWood,
);